# HRB-Sans

A retro game-style pixel font composed of square dots.

## Overview
- Font Name: HRB-Sans
- Format: TTF
- Characters Included: Alphanumeric characters only (A-Z,  0-9)

## Recommended Tool for SVG Conversion
If you want to convert this font into SVG paths, we highly recommend using the following online tool to ensure the overlapping paths are processed correctly without getting pixel glitches:
- Text to SVG (https://text-to-svg.com)

## Terms of Use (License)
This font is free for both personal and commercial use.

### Allowed
- Use in printed materials, websites, videos, and games.
- Creation of logos, fanzines, and banners.
- Monetization in video streaming, such as YouTube (commercial use).

### Prohibited
- Redistributing, selling, or reselling the font file itself.
- Secondary distribution of modified font data.
- Trademark registration (using the font to register a trademark logo).
- Use in illegal media or content that violates public order and morals.

## Disclaimer
The creator assumes no responsibility or liability for any damages or disadvantages resulting from the use of this font. Please use it at your own risk.

## Author and Contact
- Created by: jo zennyoji
- Scratch: -hairebe- (https://scratch.mit.edu/projects/1374966879/)
- Website / Download: [Insert your download link here]

---
### Changelog
- August 26, 2026: v1.0.0 Released
